CREATE TABLE `focus` (
	`owner` text PRIMARY KEY NOT NULL,
	`scope` text
);

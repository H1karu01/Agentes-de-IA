CREATE TABLE `agent_connections` (
	`owner` text NOT NULL,
	`agent` text NOT NULL,
	`connection_id` text NOT NULL,
	PRIMARY KEY(`owner`, `agent`)
);
--> statement-breakpoint
CREATE TABLE `connections` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`provider` text NOT NULL,
	`model` text NOT NULL,
	`kind` text NOT NULL,
	`secret` text NOT NULL,
	`status` text DEFAULT 'unverified' NOT NULL,
	`tested` text,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `generations` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`scope` text NOT NULL,
	`prompt` text NOT NULL,
	`model` text NOT NULL,
	`mime` text NOT NULL,
	`created` text NOT NULL
);

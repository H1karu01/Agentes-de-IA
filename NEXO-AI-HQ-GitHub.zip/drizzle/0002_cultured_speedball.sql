CREATE TABLE `catalogs` (
	`owner` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL
);

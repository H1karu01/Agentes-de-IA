import urllib.request, urllib.error, http.cookiejar, json, uuid
base='http://127.0.0.1:5173'
jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(path,body=None,origin=base,authenticated=True):
 headers={'Content-Type':'application/json','Origin':origin};req=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
 try:
  res=(client if authenticated else urllib.request.build_opener()).open(req);return res.status,json.load(res)
 except urllib.error.HTTPError as e:
  raw=e.read().decode();return e.code,json.loads(raw) if raw.startswith('{') else {'error':raw[:200]}
assert call('/api/hq',authenticated=False)[0]==401
client.open(base+'/signin-with-chatgpt').read()
code,d=call('/api/hq');assert code==200,d
s=d['state'];scope={'company':'c1','project':'p1'}
def send(action,**kwargs):
 global s
 code,d=call('/api/hq',dict(scope,version=s['version'],action=action,**kwargs))
 assert code==200,(code,d)
 s=d['state'];return d
send('chat',agents=['atlas','max'],text='Prueba HTTP: plan de campaña',mode='demo',web=False)
assert s['messages'][-1]['agent']=='max'
assert len(s['messages'][-1]['sources'])==0
code,d=call('/api/hq?company=c2&project=p1');assert code==200
assert not any(m['text']=='Prueba HTTP: plan de campaña' for m in d['state']['messages'])
code,d=call('/api/hq',dict(scope,version=s['version'],action='propose',type='task',payload={'title':'x','agent':'max'}),origin='https://attacker.example');assert code==403
code,d=call('/api/hq',dict(scope,version=-1,action='propose',type='task',payload={'title':'x','agent':'max'}));assert code==409
send('propose',type='company',payload={'name':'Empresa de prueba '+str(uuid.uuid4())[:8]})
a=s['approvals'][0];send('decide',id=a['id'],approve=True)
code,d=call('/api/hq');assert any(c['id']==a['payload']['id'] for c in d['companies'])
code,d=call('/api/hq?company='+a['payload']['id']+'&project=p1');assert code==200;assert d['state']['tasks']==[]
s=call('/api/hq')[1]['state'];send('propose',type='project',payload={'name':'Proyecto aislado de prueba'})
a=s['approvals'][0];send('decide',id=a['id'],approve=True)
assert call('/api/hq?company=c1&project='+a['payload']['id'])[0]==200
assert call('/api/hq?company=c2&project='+a['payload']['id'])[0]!=200
send('propose',type='focus',payload={'enabled':True});a=s['approvals'][0];send('decide',id=a['id'],approve=True)
assert call('/api/hq')[1]['state']['focus'] is True
scope={'company':'c2','project':'p1'};s=call('/api/hq?company=c2&project=p1')[1]['state'];send('propose',type='focus',payload={'enabled':True});a=s['approvals'][0];send('decide',id=a['id'],approve=True)
assert call('/api/hq')[1]['state']['focus'] is False
print('PASS HTTP: autenticación, chat grupal, aislamiento, CSRF, conflicto, nuevas empresas/proyectos y foco global')

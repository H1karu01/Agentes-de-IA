import sqlite3, pathlib, json
conn=sqlite3.connect(':memory:')
conn.executescript(pathlib.Path('drizzle/0000_messy_agent_zero.sql').read_text())
for owner,scope in [('alice','c1:p1'),('bob','c1:p1'),('alice','c2:p1'),('alice','c1:p2')]:
 conn.execute('INSERT INTO states VALUES(?,?,0,?)',(owner,scope,json.dumps({'secret':owner+scope})))
row=conn.execute('SELECT data FROM states WHERE owner=? AND scope=?',('alice','c1:p1')).fetchone()
assert json.loads(row[0])['secret']=='alicec1:p1'
assert conn.execute('SELECT data FROM states WHERE owner=? AND scope=?',('mallory','c1:p1')).fetchone() is None
q='UPDATE states SET data=?,version=version+1 WHERE owner=? AND scope=? AND version=?'
assert conn.execute(q,('{}','alice','c1:p1',0)).rowcount==1
assert conn.execute(q,('{}','alice','c1:p1',0)).rowcount==0
conn.execute("INSERT INTO audit SELECT 'stale','alice','c1:p1','update','blocked','now' WHERE changes()=1")
assert conn.execute('SELECT COUNT(*) FROM audit').fetchone()[0]==0
print('PASS: aislamiento entre usuarios, empresas, proyectos; versión concurrente y auditoría condicional')

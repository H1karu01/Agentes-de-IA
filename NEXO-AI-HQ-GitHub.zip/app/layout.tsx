import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'NEXO AI HQ · Tu agencia, conectada',description:'Centro de operaciones de agentes IA. Empresas, proyectos y decisiones en un solo lugar.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}
